import SwiftUI
import MapKit
import Photos

struct ContentView: View {
    @State private var mapView = MKMapView()

    var body: some View {
        MapViewWrapper(mapView: $mapView)
            .onAppear(perform: checkPhotoLibraryPermission)
            .edgesIgnoringSafeArea(.all)
    }

    func checkPhotoLibraryPermission() {
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .authorized:
            fetchPhotos()
        case .denied, .restricted:
            // Handle access denied
            break
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { status in
                if status == .authorized {
                    fetchPhotos()
                }
            }
        default:
            break
        }
    }

    func fetchPhotos() {
        let fetchOptions = PHFetchOptions()
        let oneYearAgo = Calendar.current.date(byAdding: .year, value: -1, to: Date())
        fetchOptions.predicate = NSPredicate(format: "creationDate > %@", oneYearAgo! as CVarArg)
        let assets = PHAsset.fetchAssets(with: .image, options: fetchOptions)

        var locations = [CLLocationCoordinate2D]()
        assets.enumerateObjects { asset, _, _ in
            if let location = asset.location?.coordinate {
                locations.append(location)
            }
        }

        plotLocations(locations)
    }

    func plotLocations(_ locations: [CLLocationCoordinate2D]) {
        for location in locations {
            let annotation = MKPointAnnotation()
            annotation.coordinate = location
            mapView.addAnnotation(annotation)
        }

        if let firstLocation = locations.first {
            let region = MKCoordinateRegion(center: firstLocation, span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1))
            mapView.setRegion(region, animated: true)
        }
    }
}

struct MapViewWrapper: UIViewRepresentable {
    @Binding var mapView: MKMapView

    func makeUIView(context: Context) -> MKMapView {
        return mapView
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {
        // Handle updates
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
