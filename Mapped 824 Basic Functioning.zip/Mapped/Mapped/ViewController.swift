import UIKit
import Photos
import MapKit

class ViewController: UIViewController {
    @IBOutlet weak var mapView: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()
        checkPhotoLibraryPermission()
    }

    func checkPhotoLibraryPermission() {
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .authorized:
            fetchPhotos()
        case .denied, .restricted:
            // Handle access denied
            break
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { status in
                if status == .authorized {
                    self.fetchPhotos()
                }
            }
        default:
            break
        }
    }

    func fetchPhotos() {
        let fetchOptions = PHFetchOptions()
        let oneYearAgo = Calendar.current.date(byAdding: .year, value: -1, to: Date())
        fetchOptions.predicate = NSPredicate(format: "creationDate > %@", oneYearAgo! as CVarArg)
        let assets = PHAsset.fetchAssets(with: .image, options: fetchOptions)

        var locations = [CLLocationCoordinate2D]()
        assets.enumerateObjects { asset, _, _ in
            if let location = asset.location?.coordinate {
                locations.append(location)
            }
        }

        plotLocations(locations)
    }

    func plotLocations(_ locations: [CLLocationCoordinate2D]) {
        for location in locations {
            let annotation = MKPointAnnotation()
            annotation.coordinate = location
            mapView.addAnnotation(annotation)
        }

        if let firstLocation = locations.first {
            let region = MKCoordinateRegion(center: firstLocation, span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1))
            mapView.setRegion(region, animated: true)
        }
    }
}
