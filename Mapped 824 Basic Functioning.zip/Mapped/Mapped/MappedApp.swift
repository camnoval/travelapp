//
//  MappedApp.swift
//  Mapped
//
//  Created by Noval, Cam on 8/23/24.
//

import SwiftUI

@main
struct MappedApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
